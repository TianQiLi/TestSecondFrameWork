//
//  TestSecondFrameWork.h
//  TestSecondFrameWork
//
//  Created by litianqi on 2019/5/20.
//  Copyright © 2019 edu24ol. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TestSecondFrameWork/TestStringObject.h>
//! Project version number for TestSecondFrameWork.
FOUNDATION_EXPORT double TestSecondFrameWorkVersionNumber;

//! Project version string for TestSecondFrameWork.
FOUNDATION_EXPORT const unsigned char TestSecondFrameWorkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestSecondFrameWork/PublicHeader.h>


